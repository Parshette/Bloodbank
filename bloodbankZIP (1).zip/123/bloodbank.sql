-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3307
-- Generation Time: Jun 06, 2022 at 04:05 PM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 8.1.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `bloodbank`
--

-- --------------------------------------------------------

--
-- Table structure for table `newdonorr`
--

CREATE TABLE `newdonorr` (
  `Donar_No` varchar(20) NOT NULL,
  `Donor_Name` varchar(20) NOT NULL,
  `Blood_Group` varchar(20) NOT NULL,
  `Sex` varchar(20) NOT NULL,
  `Age` varchar(20) NOT NULL,
  `Date` varchar(20) NOT NULL,
  `Country` varchar(20) NOT NULL,
  `City` varchar(20) NOT NULL,
  `Mobile` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `newdonorr`
--

INSERT INTO `newdonorr` (`Donar_No`, `Donor_Name`, `Blood_Group`, `Sex`, `Age`, `Date`, `Country`, `City`, `Mobile`) VALUES
('3', 'rmgke', 'Female', '21', 'AB', '432', 'kek', 'ew', 'er'),
('4', 'name', 'B', 'Male', '21/6', 'india', 'LAtur', '122324423', '21'),
('5', 'name2', 'A', 'Male', 'india', 'nagpur', '94502', '20', '23/4'),
('6', 'naem3', 'A', 'Male', '85', '24/5', 'India', 'LAtur', '84597293'),
('84', 'nads', 'O', 'Female', '23', '34/2', 'india', 'ALre', '233431'),
('90', 'nsdn', 'O', 'Female', '20', '3892', 'indai', 'ALtue', '82938'),
('23', 'snd', 'AB', 'Male', '34', '34', 'isdin', 'df', 'sdf'),
('23', '34rm', 'A', 'Male', '34', 'er3', 'ete', 'gfdg', 'dfd'),
('34', 'uru', 'B', 'Male', '89', '230', 'oein', 'ldk', '234'),
('10', 'Shubhash', 'B', 'Male', '20', '26/05/2022', 'India', 'Pune', '1234567890');

-- --------------------------------------------------------

--
-- Table structure for table `quantityy`
--

CREATE TABLE `quantityy` (
  `packets` int(100) NOT NULL,
  `group11` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `quantityy`
--

INSERT INTO `quantityy` (`packets`, `group11`) VALUES
(0, 'A'),
(2, 'B'),
(0, 'O'),
(0, 'AB');

-- --------------------------------------------------------

--
-- Table structure for table `sell`
--

CREATE TABLE `sell` (
  `No` varchar(100) NOT NULL,
  `Name` varchar(100) NOT NULL,
  `Mobile` varchar(10) NOT NULL,
  `Address` varchar(100) NOT NULL,
  `Date` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `sell`
--

INSERT INTO `sell` (`No`, `Name`, `Mobile`, `Address`, `Date`) VALUES
('34', 'sd', 'sd', 'dfd', 'sdds'),
('76', 'fdgfsd', 'fg', 'dfvd', 'rd'),
('', '', '', '', '');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
