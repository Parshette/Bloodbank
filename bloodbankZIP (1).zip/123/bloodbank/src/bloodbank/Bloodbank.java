
package bloodbank;


public class Bloodbank {

    
    public static void main(String[] args) {
        // TODO code application logic here
        
        first m=new first();
        m.setVisible(true);
    }
    
}
